let display = document.getElementById('display');

function append(value) {
  display.value += value;
}

function clearDisplay() {
  display.value = '';
}

function del() {
  display.value = display.value.slice(0, -1);
}

function calculate() {
  try {
    let expression = display.value.replace(/%/g, '/100');
    display.value = eval(expression);
  } catch (e) {
    display.value = 'Error';
  }
}

// Keyboard support
window.addEventListener('DOMContentLoaded', () => {
  display.focus();
});

document.addEventListener('keydown', function(e) {
  const key = e.key;
  if ((key >= '0' && key <= '9') || key === '.' || key === '+' || key === '-' || key === '*' || key === '/' || key === '%') {
    append(key);
    highlightButton(key);
  } else if (key === 'Enter' || key === '=') {
    calculate();
    highlightButton('=');
    e.preventDefault();
  } else if (key === 'Backspace') {
    del();
    highlightButton('DEL');
    e.preventDefault();
  } else if (key === 'Escape' || key === 'c' || key === 'C') {
    clearDisplay();
    highlightButton('C');
    e.preventDefault();
  }
});

function highlightButton(key) {
  let btn;
  if (key === 'Enter' || key === '=') {
    btn = document.querySelector('.btn-equals');
  } else if (key === 'Backspace' || key === 'DEL') {
    btn = document.querySelector('.btn-del');
  } else if (key === 'Escape' || key === 'C' || key === 'c') {
    btn = document.querySelector('.btn-clear');
  } else {
    btn = Array.from(document.querySelectorAll('.btn')).find(b => b.textContent === key);
  }
  if (btn) {
    btn.classList.add('active-key');
    setTimeout(() => btn.classList.remove('active-key'), 150);
  }
}
